import * as TypeMoq from 'typemoq';

export {TypeMoq};
