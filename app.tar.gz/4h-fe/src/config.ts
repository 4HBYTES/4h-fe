export class ServerConfig {
  public static readonly CMS_URL:string = 'http://shindagha-cms.wowi.io';
  public static readonly PAYMENT_URL:string = 'http://shindagha-payment.wowi.io';
}
