import {Component} from '@angular/core';

@Component({
  selector:'h4fe-footer-component',
  templateUrl:'footer.component.html',
  styles:[require('!css-loader!resolve-url-loader!postcss-loader!sass-loader?sourceMap!./footer.component.scss')[0][1]]
})
export class FooterComponent {

}
