import {Component} from '@angular/core';

@Component({
  selector:'h4fe-contact-component',
  templateUrl:'contact.component.html',
  styles:[require('!css-loader!resolve-url-loader!postcss-loader!sass-loader?sourceMap!./contact.component.scss')[0][1]]
})
export class ContactComponent {

}
