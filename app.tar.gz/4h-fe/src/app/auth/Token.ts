export type Token = string;

export interface TokenResponse {
  token:Token;
}
