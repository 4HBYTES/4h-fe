declare type Url = string;

export {Url};
