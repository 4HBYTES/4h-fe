const path = require('path');
const merge = require('webpack-merge');

// Helper functions
const ROOT = path.resolve(__dirname, '..');

function hasProcessFlag(flag) {
  return process.argv.join('').indexOf(flag) > -1;
}

function isWebpackDevServer() {
  return process.argv[1] && !!/webpack-dev-server$/.exec(process.argv[1]);
}

function root(args) {
  args = Array.prototype.slice.call(arguments, 0);
  return path.join.apply(path, [ROOT].concat(args));
}

function checkNodeImport(context, request, cb) {
  if (!path.isAbsolute(request) && request.charAt(0) !== '.') {
    cb(null, 'commonjs ' + request);
    return;
  }
  cb();
}

function applyCommonCapabilities(config) {
  config.multiCapabilities.forEach((caps) => {
    /* eslint-disable guard-for-in */
    for (var i in config.commonCapabilities) {
      caps[i] = caps[i] || config.commonCapabilities[i];
    }
  });
}

function getEnvironmentVariable(name) {
  return JSON.stringify(process.env[name]);
}

function isProduction() {
  return getEnvironmentVariable('ENV') === 'production';
}

function isDevelopment() {
  return getEnvironmentVariable('ENV') === 'development';
}

exports.hasProcessFlag = hasProcessFlag;
exports.isWebpackDevServer = isWebpackDevServer;
exports.root = root;
exports.checkNodeImport = checkNodeImport;
exports.applyCommonCapabilities = applyCommonCapabilities;
exports.merge = merge;
exports.getEnvironmentVariable = getEnvironmentVariable;
exports.isProduction = isProduction;
exports.isDevelopment = isDevelopment;
